'use strict';
// End-to-end smoke test: starts the server, two players join, host starts, roll happens, SSE delivers state.
process.env.PORT = '3917';
const http = require('http');
require('../server.js');
const base = 'http://127.0.0.1:3917';
const post = (p, b) => new Promise((res, rej) => {
  const d = JSON.stringify(b);
  const r = http.request(base + p, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(d) } }, (x) => { let s = ''; x.on('data', (c) => (s += c)); x.on('end', () => res(JSON.parse(s))); });
  r.on('error', rej); r.end(d);
});
const get = (p) => new Promise((res, rej) => http.get(base + p, (x) => { let s = ''; x.on('data', (c) => (s += c)); x.on('end', () => res({ status: x.statusCode, body: s, type: x.headers['content-type'] })); }).on('error', rej));
function sse(path, onState) {
  http.get(base + path, (x) => { x.setEncoding('utf8'); let buf = ''; x.on('data', (c) => { buf += c; let i; while ((i = buf.indexOf('\n\n')) >= 0) { const ev = buf.slice(0, i); buf = buf.slice(i + 2); const m = ev.match(/^data: (.*)$/m); if (m) onState(JSON.parse(m[1])); } }); });
}
const ok = (c, m) => { if (!c) { console.error('FAIL:', m); process.exit(1); } console.log('ok  -', m); };
(async () => {
  const idx = await get('/'); ok(idx.status === 200 && idx.type.includes('html'), 'serves index.html');
  for (const f of ['/app.js', '/style.css']) ok((await get(f)).status === 200, 'serves ' + f);
  ok((await get('/../server.js')).status === 404, 'blocks path traversal');
  ok((await get('/%2e%2e/server.js')).status === 404, 'blocks encoded path traversal');
  const board = JSON.parse((await get('/api/board')).body); ok(board.length === 40, 'board has 40 squares');
  const a = await post('/api/create', { name: 'Ann' }); ok(a.code && a.code.length === 4, 'room created ' + a.code);
  let stA = null, stB = null;
  sse(`/api/events?code=${a.code}&pid=${a.pid}&secret=${a.secret}`, (s) => (stA = s));
  const b = await post('/api/join', { name: 'Bob', code: a.code.toLowerCase() }); ok(b.pid === 2, 'Bob joined (case-insensitive code)');
  sse(`/api/events?code=${b.code}&pid=${b.pid}&secret=${b.secret}`, (s) => (stB = s));
  await new Promise((r) => setTimeout(r, 300));
  ok(stA && stA.players.length === 2 && stB.you === 2, 'both receive lobby state over SSE');
  ok((await post('/api/act', { code: a.code, pid: b.pid, secret: b.secret, a: 'start' })).error, 'non-host cannot start');
  ok((await post('/api/act', { code: a.code, pid: a.pid, secret: 'wrong', a: 'start' })).error, 'bad secret rejected');
  ok((await post('/api/act', { code: a.code, pid: a.pid, secret: a.secret, a: 'start' })).ok, 'host starts game');
  await new Promise((r) => setTimeout(r, 200));
  ok(stB.phase === 'roll' && stB.players.every((p) => p.money === 1500), 'game running, 1500 each');
  const first = stA.players[stA.turn];
  const tok = first.id === a.pid ? a : b;
  ok((await post('/api/act', { code: a.code, pid: tok.pid, secret: tok.secret, a: 'roll' })).ok, 'current player rolls');
  await new Promise((r) => setTimeout(r, 200));
  ok(stA.rollSeq === 1 && !stA.decks, 'roll broadcast, deck order hidden');
  const other = first.id === a.pid ? b : a;
  ok((await post('/api/act', { code: a.code, pid: other.pid, secret: other.secret, a: 'roll' })).error, "can't roll out of turn");
  const j = await post('/api/join', { name: 'Late', code: a.code }); ok(j.error, 'cannot join after start');
  console.log('\nALL SMOKE TESTS PASSED'); process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });
