'use strict';
// Random-play simulation: runs many full games against the engine and checks invariants.
const game = require('../game');
const { BOARD } = game;

const pick = (a) => a[Math.floor(Math.random() * a.length)];
const GAMES = +process.argv[2] || 300;
const MAX_STEPS = 6000;
let finished = 0, stalled = 0, errors = 0;
const actCounts = {};

function check(g, ctx) {
  for (const p of g.players) {
    if (!Number.isFinite(p.money) || p.money < 0 || !Number.isInteger(p.money)) throw new Error(`bad money ${p.money} for ${p.name} (${ctx})`);
    if (p.pos < 0 || p.pos > 39) throw new Error('bad pos');
  }
  let houses = 0, hotels = 0;
  for (const i of Object.keys(g.props)) {
    const st = g.props[i];
    if (st.owner !== null) {
      const o = g.players.find((p) => p.id === st.owner);
      if (!o) throw new Error('owner missing');
      if (o.bankrupt) throw new Error('bankrupt player owns property ' + BOARD[i].name);
    } else if (st.houses || st.mortgaged) throw new Error('unowned property has buildings/mortgage');
    if (st.houses === 5) hotels++; else houses += st.houses;
  }
  if (houses + g.housesLeft !== 32 && g.phase !== 'lobby') throw new Error(`house supply mismatch ${houses}+${g.housesLeft}`);
  if (hotels + g.hotelsLeft !== 12) throw new Error('hotel supply mismatch');
  const jc = g.players.reduce((n, p) => n + p.jailCards.length, 0);
  const inDecks = g.decks.chest.length + g.decks.chance.length;
  if (jc + inDecks !== 32) throw new Error(`card count mismatch ${jc}+${inDecks}`);
}

function doAct(g, pid, m) {
  const err = game.act(g, pid, m);
  actCounts[m.a] = (actCounts[m.a] || 0) + 1;
  return err;
}

function playOne() {
  const g = game.newGame({ startCash: pick([500, 1500]), jackpot: Math.random() < 0.5 });
  const n = 2 + Math.floor(Math.random() * 5);
  for (let i = 0; i < n; i++) game.addPlayer(g, 'P' + i);
  if (doAct(g, 1, { a: 'start' })) throw new Error('start failed');
  for (let step = 0; step < MAX_STEPS; step++) {
    if (g.phase === 'over') { finished++; return; }
    const cp = game.cur(g);
    // random management by anyone
    if (Math.random() < 0.25 && g.phase !== 'auction') {
      const q = pick(g.players.filter((p) => !p.bankrupt));
      const owned = game.ownedBy(g, q.id);
      if (owned.length) doAct(g, q.id, { a: pick(['build', 'build', 'sell', 'mortgage', 'unmortgage']), idx: pick(owned) });
    }
    // random trades
    if (Math.random() < 0.05 && !g.trade && g.phase !== 'auction') {
      const q = pick(g.players.filter((p) => !p.bankrupt)), r = pick(g.players.filter((p) => !p.bankrupt && p.id !== q.id));
      if (r) {
        const qo = game.ownedBy(g, q.id), ro = game.ownedBy(g, r.id);
        doAct(g, q.id, { a: 'tradePropose', to: r.id, offer: { money: Math.floor(Math.random() * 200), props: qo.length ? [pick(qo)] : [], cards: 0 }, request: { money: Math.floor(Math.random() * 200), props: ro.length ? [pick(ro)] : [], cards: Math.random() < 0.3 ? 1 : 0 } });
      }
    }
    if (g.trade) doAct(g, g.trade.to, { a: pick(['tradeAccept', 'tradeDecline', 'tradeDecline']) });
    switch (g.phase) {
      case 'roll':
        if (cp.inJail && Math.random() < 0.3) doAct(g, cp.id, { a: pick(['payJail', 'useJailCard']) });
        doAct(g, cp.id, { a: 'roll' }); break;
      case 'buy': doAct(g, cp.id, { a: Math.random() < 0.6 ? 'buy' : 'decline' }); break;
      case 'end': doAct(g, cp.id, { a: 'endTurn' }); break;
      case 'auction':
        for (const p of g.players.filter((x) => !x.bankrupt)) {
          if (g.phase !== 'auction') break;
          if (Math.random() < 0.5) doAct(g, p.id, { a: 'bid', amount: g.auction.bid + 1 + Math.floor(Math.random() * 50) });
          else doAct(g, p.id, { a: 'pass' });
        }
        break;
      case 'debt': {
        const d = g.debt, p = game.P(g, d.pid);
        const owned = game.ownedBy(g, p.id);
        for (const i of owned) { if (p.money >= d.amount) break; doAct(g, p.id, { a: 'sell', idx: i }); doAct(g, p.id, { a: 'mortgage', idx: i }); }
        if (p.money >= d.amount) { const e = doAct(g, p.id, { a: 'payDebt' }); if (e) throw new Error('payDebt failed: ' + e); }
        else doAct(g, p.id, { a: 'bankrupt' });
        break;
      }
      default: throw new Error('unexpected phase ' + g.phase);
    }
    check(g, 'step ' + step);
  }
  stalled++;
}

for (let i = 0; i < GAMES; i++) {
  try { playOne(); } catch (e) { errors++; console.error('GAME ERROR:', e.stack); if (errors > 3) break; }
}
console.log(`games=${GAMES} finished=${finished} hit-step-cap=${stalled} errors=${errors}`);
console.log('action counts:', JSON.stringify(actCounts));
process.exit(errors ? 1 : 0);
