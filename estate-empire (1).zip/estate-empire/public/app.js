'use strict';
const $ = (s) => document.querySelector(s);
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const money = (n) => '$' + Number(n).toLocaleString('en-US');
const GCOL = { brown: '#8d5a3b', lightblue: '#9bd8f5', pink: '#e75fa5', orange: '#f39c3d', red: '#e03a3a', yellow: '#f6dc3b', green: '#2e9e5b', darkblue: '#2b4fb3' };
const GORDER = ['brown', 'lightblue', 'pink', 'orange', 'red', 'yellow', 'green', 'darkblue'];
const FACES = ['⚀', '⚁', '⚂', '⚃', '⚄', '⚅'];
const ICONS = { go: '🏁', chest: '📦', chance: '❓', tax: '💰', jail: '🔒', parking: '🅿️', gotojail: '👮', station: '🚆', utility: '💡' };

let BOARD = [], S = null, me = null, code = null, secret = null, es = null;
let ui = { modal: null, lastModalKey: '' };
let lastRollSeq = -1, rollTimer = null, shownDice = null;

// ---------- networking ----------
async function api(path, body) {
  try {
    const r = await fetch('/api/' + path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    return await r.json();
  } catch (e) { return { error: 'Cannot reach the server' }; }
}
async function act(a, extra) {
  const r = await api('act', Object.assign({ code, pid: me, secret, a }, extra || {}));
  if (r.error) toast(r.error);
  return r;
}
let toastTimer;
function toast(msg) {
  const t = $('#toast'); t.textContent = msg; t.hidden = false;
  clearTimeout(toastTimer); toastTimer = setTimeout(() => (t.hidden = true), 3200);
}

function saveSession() { try { localStorage.setItem('ee-session', JSON.stringify({ code, pid: me, secret })); } catch (e) {} }
function clearSession() { try { localStorage.removeItem('ee-session'); } catch (e) {} }

function connect() {
  if (es) es.close();
  let gotData = false;
  es = new EventSource(`/api/events?code=${code}&pid=${me}&secret=${secret}`);
  es.onmessage = (e) => { gotData = true; $('#conn').hidden = true; S = JSON.parse(e.data); render(); };
  es.onerror = () => {
    $('#conn').hidden = false;
    if (!gotData) setTimeout(() => { if (!gotData) { es.close(); clearSession(); S = null; show('home'); $('#home-err').textContent = 'That room no longer exists.'; $('#conn').hidden = true; } }, 4000);
  };
}

function show(which) {
  $('#home').hidden = which !== 'home';
  $('#lobby').hidden = which !== 'lobby';
  $('#game').hidden = which !== 'game';
  if (which !== 'game') { $('#modal').hidden = true; ui.lastModalKey = ''; }
}

// ---------- home ----------
$('#name').value = (() => { try { return localStorage.getItem('ee-name') || ''; } catch (e) { return ''; } })();
async function enter(r) {
  if (r.error) { $('#home-err').textContent = r.error; return; }
  code = r.code; me = r.pid; secret = r.secret; saveSession(); connect();
}
function getName() {
  const n = $('#name').value.trim();
  try { localStorage.setItem('ee-name', n); } catch (e) {}
  return n;
}
$('#btn-create').onclick = async () => {
  if (!getName()) { $('#home-err').textContent = 'Enter your name first'; return; }
  enter(await api('create', { name: getName() }));
};
$('#btn-join').onclick = async () => {
  if (!getName()) { $('#home-err').textContent = 'Enter your name first'; return; }
  enter(await api('join', { name: getName(), code: $('#code').value.trim() }));
};
$('#code').addEventListener('keydown', (e) => { if (e.key === 'Enter') $('#btn-join').click(); });
$('#name').addEventListener('keydown', (e) => { if (e.key === 'Enter') ($('#code').value ? $('#btn-join') : $('#btn-create')).click(); });

// ---------- lobby ----------
$('#btn-start').onclick = () => act('start');
function renderLobby() {
  $('#lobby-code').textContent = code;
  const host = S.hostId === me;
  $('#lobby-players').innerHTML = S.players.map((p) => `
    <div class="lp"><span class="tok">${p.token}</span><b style="color:${p.color}">${esc(p.name)}</b>
    ${p.id === S.hostId ? '<small>host</small>' : ''}${p.connected ? '' : '<small>offline</small>'}
    ${host && p.id !== me ? `<button class="x" data-act="kick" data-id="${p.id}" title="Remove">✕</button>` : ''}</div>`).join('');
  const st = S.settings;
  $('#lobby-settings').innerHTML = host ? `
    <div class="settings-row"><label>Starting cash</label>
      <select id="set-cash">${[1000, 1500, 2000, 3000, 5000].map((v) => `<option value="${v}" ${v === st.startCash ? 'selected' : ''}>${money(v)}</option>`).join('')}</select></div>
    <div class="settings-row"><label for="set-jp">Free Parking jackpot (taxes go to the pot)</label><input type="checkbox" id="set-jp" ${st.jackpot ? 'checked' : ''}></div>`
    : `<p class="sub">Starting cash ${money(st.startCash)} · Free Parking jackpot ${st.jackpot ? 'on' : 'off'}</p>`;
  if (host) {
    $('#set-cash').onchange = (e) => act('settings', { startCash: +e.target.value });
    $('#set-jp').onchange = (e) => act('settings', { jackpot: e.target.checked });
  }
  $('#btn-start').hidden = !host;
  $('#btn-start').disabled = S.players.length < 2;
  $('#lobby-wait').textContent = host ? (S.players.length < 2 ? 'Waiting for at least one more player…' : '') : 'Waiting for the host to start…';
}

// ---------- board ----------
function pos(i) {
  if (i === 0) return [11, 11];
  if (i < 10) return [11, 11 - i];
  if (i === 10) return [11, 1];
  if (i < 20) return [11 - (i - 10), 1];
  if (i === 20) return [1, 1];
  if (i < 30) return [1, 1 + (i - 20)];
  if (i === 30) return [1, 11];
  return [1 + (i - 30), 11];
}
function sqHTML(i) {
  const s = BOARD[i], [r, c] = pos(i), st = S.props[i];
  const cur = S.phase !== 'lobby' && S.players[S.turn];
  const corner = [0, 10, 20, 30].includes(i);
  let cls = 'sq' + (corner ? ' corner' : '');
  if (st && st.mortgaged) cls += ' mort';
  if (cur && cur.pos === i && !cur.bankrupt) cls += ' turn';
  let inner = '';
  if (s.type === 'prop') {
    let hs = '';
    if (st.houses === 5) hs = '<i class="hotel"></i>'; else for (let k = 0; k < st.houses; k++) hs += '<i class="h"></i>';
    inner = `<div class="band" style="background:${GCOL[s.group]}">${hs}</div><div class="nm">${esc(s.name)}</div><div class="pr">${money(s.price)}</div>`;
  } else if (s.type === 'station' || s.type === 'utility') {
    const ic = s.type === 'utility' ? (i === 28 ? '🚰' : '💡') : ICONS.station;
    inner = `<div class="ic">${ic}</div><div class="nm">${esc(s.name)}</div><div class="pr">${money(s.price)}</div>`;
  } else {
    inner = `<div class="ic">${ICONS[s.type]}</div><div class="nm">${esc(s.name)}${s.amount ? '<br>' + money(s.amount) : ''}${s.type === 'parking' && S.settings.jackpot ? '<br>Pot ' + money(S.pot) : ''}</div>`;
  }
  const owner = st && st.owner ? S.players.find((p) => p.id === st.owner) : null;
  if (owner) inner += `<div class="own" style="background:${owner.color}"></div>`;
  const here = S.players.filter((p) => !p.bankrupt && p.pos === i);
  if (here.length) inner += `<div class="tokens">${here.map((p) => `<span class="tok" style="border-color:${p.color}">${p.token}</span>`).join('')}</div>`;
  return `<div class="${cls}" data-sq="${i}" style="grid-area:${r}/${c}">${inner}</div>`;
}

function diceHTML() {
  const d = shownDice || S.dice;
  return `<div class="dice${rollTimer ? ' rolling' : ''}" id="dice"><span>${FACES[d[0] - 1]}</span><span>${FACES[d[1] - 1]}</span></div>`;
}

function centerHTML() {
  const cp = S.players[S.turn], mine = cp.id === me;
  const mp = S.players.find((p) => p.id === me);
  let status = '', acts = '', small = '';
  const nm = esc(cp.name);
  switch (S.phase) {
    case 'roll':
      if (mine) {
        status = cp.inJail ? `You're in Jail (turn ${cp.jailTurns + 1}/3)` : (S.doubles ? 'Doubles! Roll again' : 'Your turn!');
        if (cp.inJail) {
          acts = `<button data-act="payJail" ${cp.money < 50 ? 'disabled' : ''}>Pay $50</button>` +
            (cp.jailCards.length ? '<button data-act="useJailCard">Use free card</button>' : '') +
            '<button class="primary" data-act="roll">Roll for doubles</button>';
        } else acts = '<button class="primary" data-act="roll">🎲 Roll dice</button>';
      } else status = `${nm} is ${cp.inJail ? 'in Jail…' : 'about to roll…'}`;
      break;
    case 'buy': {
      const sq = BOARD[S.pendingBuy];
      if (mine) {
        status = `Buy ${esc(sq.name)} for ${money(sq.price)}?`;
        small = `You have ${money(cp.money)}`;
        acts = `<button class="good" data-act="buy" ${cp.money < sq.price ? 'disabled' : ''}>Buy</button><button data-act="decline">Auction it</button>`;
      } else status = `${nm} is deciding on ${esc(sq.name)}…`;
      break;
    }
    case 'end':
      if (mine) { status = 'Done? Manage your properties or…'; acts = '<button class="primary" data-act="endTurn">End turn</button>'; }
      else status = `${nm} is finishing their turn…`;
      break;
    case 'debt': {
      const d = S.debt, who = S.players.find((p) => p.id === d.pid);
      if (d.pid === me) {
        status = `You owe ${money(d.amount)}!`;
        small = `${esc(d.reason)} · you have ${money(who.money)}. Mortgage or sell buildings on the right, then pay.`;
        acts = `<button class="good" data-act="payDebt" ${who.money < d.amount ? 'disabled' : ''}>Pay ${money(d.amount)}</button><button class="danger" id="btn-bankrupt">Declare bankruptcy</button>`;
      } else status = `${esc(who.name)} owes ${money(d.amount)} and is raising cash…`;
      break;
    }
    case 'auction': status = 'Auction in progress'; break;
    case 'over': {
      const w = S.players.find((p) => p.id === S.winner);
      status = w ? `🏆 ${esc(w.name)} wins!` : 'Game over';
      acts = '<button class="primary" id="btn-leave">Back to menu</button>';
      break;
    }
  }
  let card = '';
  if (S.lastCard) {
    const cp2 = S.players.find((p) => p.id === S.lastCard.pid);
    card = `<div class="cardbox"><b>${S.lastCard.deck === 'chest' ? '📦 Community Fund' : '❓ Surprise'} – ${esc(cp2 ? cp2.name : '')}</b>${esc(S.lastCard.text)}</div>`;
  }
  return `<div class="title">ESTATE EMPIRE</div>${diceHTML()}<div class="status">${status}</div>${small ? `<div class="small">${small}</div>` : ''}<div class="acts">${acts}</div>${card}${S.settings.jackpot ? `<div class="pot">Free Parking pot: ${money(S.pot)}</div>` : ''}`;
}

function renderBoard() {
  let h = '';
  for (let i = 0; i < 40; i++) h += sqHTML(i);
  h += `<div id="center">${centerHTML()}</div>`;
  $('#board').innerHTML = h;
  const bk = $('#btn-bankrupt');
  if (bk) bk.onclick = () => { if (confirm('Really declare bankruptcy? You are out of the game.')) act('bankrupt'); };
  const lv = $('#btn-leave');
  if (lv) lv.onclick = () => { clearSession(); if (es) es.close(); S = null; show('home'); };
}

function animateDice() {
  if (S.rollSeq === lastRollSeq) return;
  const first = lastRollSeq === -1;
  lastRollSeq = S.rollSeq;
  if (first || S.rollSeq === 0) { shownDice = null; return; }
  clearInterval(rollTimer);
  let n = 0;
  rollTimer = setInterval(() => {
    shownDice = [1 + Math.floor(Math.random() * 6), 1 + Math.floor(Math.random() * 6)];
    const el = $('#dice'); if (el) { el.className = 'dice rolling'; el.innerHTML = `<span>${FACES[shownDice[0] - 1]}</span><span>${FACES[shownDice[1] - 1]}</span>`; }
    if (++n > 5) {
      clearInterval(rollTimer); rollTimer = null; shownDice = null;
      const e2 = $('#dice'); if (e2) { e2.className = 'dice'; e2.innerHTML = `<span>${FACES[S.dice[0] - 1]}</span><span>${FACES[S.dice[1] - 1]}</span>`; }
    }
  }, 90);
}

// ---------- sidebar ----------
function renderPlayers() {
  const cp = S.players[S.turn];
  $('#players').innerHTML = S.players.map((p) => `
    <div class="pl${p.id === cp.id && S.phase !== 'over' ? ' cur' : ''}${p.bankrupt ? ' out' : ''}${p.id === me ? ' me' : ''}" style="border-color:${p.color}">
      <span class="tk">${p.token}</span>
      <span class="nm">${esc(p.name)} ${p.inJail ? '🔒' : ''}${p.jailCards.length ? '🎫'.repeat(p.jailCards.length) : ''}${p.connected ? '' : ' <small>(offline)</small>'}</span>
      <span class="mo">${p.bankrupt ? 'OUT' : money(p.money)}<small>worth ${money(p.worth)}</small></span>
      ${S.hostId === me && p.id !== me && !p.bankrupt ? `<button style="padding:2px 8px" title="Remove player" data-act="kick" data-id="${p.id}" data-confirm="Remove ${esc(p.name)} from the game?">✕</button>` : ''}
    </div>`).join('');
}

function renderMine() {
  const mp = S.players.find((p) => p.id === me);
  const owned = Object.keys(S.props).map(Number).filter((i) => S.props[i].owner === me);
  owned.sort((a, b) => {
    const ga = BOARD[a].group ? GORDER.indexOf(BOARD[a].group) : (BOARD[a].type === 'station' ? 8 : 9);
    const gb = BOARD[b].group ? GORDER.indexOf(BOARD[b].group) : (BOARD[b].type === 'station' ? 8 : 9);
    return ga - gb || a - b;
  });
  const rows = owned.map((i) => {
    const s = BOARD[i], st = S.props[i], can = S.can[i] || {};
    const col = s.group ? GCOL[s.group] : (s.type === 'station' ? '#444' : '#999');
    const hs = st.houses === 5 ? '🏨' : st.houses ? '🏠'.repeat(st.houses) : '';
    let btns = '';
    if (s.type === 'prop') btns += `<button data-act="build" data-idx="${i}" title="Build (${money(s.house)})" ${can.build ? '' : 'disabled'}>＋</button><button data-act="sell" data-idx="${i}" title="Sell building" ${can.sell ? '' : 'disabled'}>－</button>`;
    btns += st.mortgaged
      ? `<button data-act="unmortgage" data-idx="${i}" title="Unmortgage for ${money(S.unmortgageCost[i] || 0)}" ${can.unmortgage ? '' : 'disabled'}>Unmortgage</button>`
      : `<button data-act="mortgage" data-idx="${i}" title="Mortgage for ${money(s.price / 2)}" ${can.mortgage ? '' : 'disabled'}>Mortgage</button>`;
    return `<div class="prow"><span class="dot" style="background:${col}"></span><span class="pn${st.mortgaged ? ' m' : ''}" data-sq="${i}">${esc(s.name)}</span><span class="hs">${hs}</span>${btns}</div>`;
  }).join('');
  const tradeOk = S.phase !== 'lobby' && S.phase !== 'over' && mp && !mp.bankrupt && !S.trade;
  $('#mine').innerHTML = `<h3><span>Your properties</span><button data-ui="trade" ${tradeOk && S.players.filter((p) => !p.bankrupt).length > 1 ? '' : 'disabled'}>🤝 Trade</button></h3>` +
    (rows || '<div class="empty">You don\'t own anything yet.</div>') +
    (S.housesLeft < 32 || S.hotelsLeft < 12 ? `<div class="empty" style="margin-top:8px;font-size:12px">Bank: ${S.housesLeft} houses · ${S.hotelsLeft} hotels left</div>` : '');
}

function renderLog() {
  const box = $('#log');
  const atBottom = box.scrollTop + box.clientHeight >= box.scrollHeight - 30;
  box.innerHTML = S.log.map((l) => l.chat ? `<div class="chat"><b style="color:${l.color}">${esc(l.name)}:</b> ${esc(l.t)}</div>` : `<div>${esc(l.t)}</div>`).join('');
  if (atBottom) box.scrollTop = box.scrollHeight;
}
$('#chatform').onsubmit = (e) => {
  e.preventDefault();
  const v = $('#chatin').value.trim(); if (!v) return;
  $('#chatin').value = ''; act('chat', { text: v });
};

// ---------- modals ----------
function pName(id) { const p = S.players.find((x) => x.id === id); return p ? esc(p.name) : '?'; }
function sideHTML(s) {
  const parts = [];
  if (s.money) parts.push(money(s.money));
  s.props.forEach((i) => parts.push(esc(BOARD[i].name)));
  if (s.cards) parts.push(`${s.cards}× Get Out of Jail Free`);
  return parts.length ? parts.join(', ') : 'nothing';
}
function deedHTML(i) {
  const s = BOARD[i], st = S.props[i];
  const owner = st && st.owner ? S.players.find((p) => p.id === st.owner) : null;
  let head = '', body = '';
  if (s.type === 'prop') {
    head = `<div class="dh" style="background:${GCOL[s.group]}">${esc(s.name)}</div>`;
    body = `<div><span>Rent</span><b>${money(s.rent[0])}</b></div><div><span>Full set (no houses)</span><b>${money(s.rent[0] * 2)}</b></div>` +
      [1, 2, 3, 4].map((n) => `<div><span>With ${n} house${n > 1 ? 's' : ''}</span><b>${money(s.rent[n])}</b></div>`).join('') +
      `<div><span>With hotel</span><b>${money(s.rent[5])}</b></div><hr><div><span>House / hotel cost</span><b>${money(s.house)} each</b></div>`;
  } else if (s.type === 'station') {
    head = `<div class="dh" style="background:#ddd">🚆 ${esc(s.name)}</div>`;
    body = [1, 2, 3, 4].map((n) => `<div><span>${n} station${n > 1 ? 's' : ''} owned</span><b>${money(25 * 2 ** (n - 1))}</b></div>`).join('');
  } else if (s.type === 'utility') {
    head = `<div class="dh" style="background:#ddd">${i === 28 ? '🚰' : '💡'} ${esc(s.name)}</div>`;
    body = '<div><span>One utility owned</span><b>4× dice roll</b></div><div><span>Both utilities owned</span><b>10× dice roll</b></div>';
  } else {
    head = `<div class="dh" style="background:#ddd">${ICONS[s.type]} ${esc(s.name)}</div>`;
    const txt = { go: 'Collect $200 every time you pass.', jail: 'Just visiting – or locked up! Leave by rolling doubles, paying $50, or using a card. After 3 failed tries you pay $50.', parking: S.settings.jackpot ? 'Land here to collect the jackpot!' : 'A free rest. Nothing happens.', gotojail: 'Go directly to Jail. Do not pass START.', chest: 'Draw a Community Fund card.', chance: 'Draw a Surprise card.', tax: `Pay ${money(s.amount || 0)}.` };
    body = `<div>${txt[s.type] || ''}</div>`;
  }
  if (s.price) body += `<hr><div><span>Price</span><b>${money(s.price)}</b></div><div><span>Mortgage value</span><b>${money(s.price / 2)}</b></div>` +
    `<div><span>Owner</span><b>${owner ? esc(owner.name) : 'Bank'}${st && st.mortgaged ? ' (mortgaged)' : ''}</b></div>`;
  return `<div class="deed">${head}<div class="db">${body}</div></div>`;
}

function propCheckboxes(pid, prefix) {
  const list = Object.keys(S.props).map(Number).filter((i) => S.props[i].owner === pid && !(BOARD[i].group && S.props && Object.keys(S.props).some((j) => BOARD[j].group === BOARD[i].group && S.props[j].houses > 0)));
  list.sort((a, b) => a - b);
  if (!list.length) return '<div class="empty">No tradeable properties</div>';
  return list.map((i) => `<label class="chk"><input type="checkbox" class="${prefix}" value="${i}"> <span style="color:${BOARD[i].group ? GCOL[BOARD[i].group] : '#bbb'}">■</span> ${esc(BOARD[i].name)}${S.props[i].mortgaged ? ' (M)' : ''}</label>`).join('');
}

function composerHTML() {
  const others = S.players.filter((p) => !p.bankrupt && p.id !== me);
  if (!ui.modal.partner || !others.some((p) => p.id === ui.modal.partner)) ui.modal.partner = others[0].id;
  const partner = S.players.find((p) => p.id === ui.modal.partner);
  const mp = S.players.find((p) => p.id === me);
  return `<div class="mbox"><h2>🤝 Propose a trade</h2>
    <label>Trade with</label>
    <select id="tr-partner">${others.map((p) => `<option value="${p.id}" ${p.id === partner.id ? 'selected' : ''}>${esc(p.name)} (${money(p.money)})</option>`).join('')}</select>
    <div class="tcols">
      <div class="tcol"><h4>You give</h4>
        <label>Cash (you have ${money(mp.money)})</label><input type="number" id="tr-om" min="0" max="${mp.money}" value="0">
        ${propCheckboxes(me, 'tr-op')}
        ${mp.jailCards.length ? `<label>Jail cards (max ${mp.jailCards.length})</label><input type="number" id="tr-oc" min="0" max="${mp.jailCards.length}" value="0">` : ''}
      </div>
      <div class="tcol"><h4>You get</h4>
        <label>Cash (they have ${money(partner.money)})</label><input type="number" id="tr-rm" min="0" max="${partner.money}" value="0">
        ${propCheckboxes(partner.id, 'tr-rp')}
        ${partner.jailCards.length ? `<label>Jail cards (max ${partner.jailCards.length})</label><input type="number" id="tr-rc" min="0" max="${partner.jailCards.length}" value="0">` : ''}
      </div>
    </div>
    <div class="btns"><button data-ui="close">Cancel</button><button class="primary" id="tr-send">Send offer</button></div></div>`;
}
function wireComposer() {
  $('#tr-partner').onchange = (e) => { ui.modal.partner = +e.target.value; ui.lastModalKey = ''; renderModal(); };
  $('#tr-send').onclick = async () => {
    const vals = (cls) => [...document.querySelectorAll('.' + cls + ':checked')].map((x) => +x.value);
    const num = (id) => { const el = $(id); return el ? Math.max(0, Math.floor(+el.value || 0)) : 0; };
    const r = await act('tradePropose', { to: ui.modal.partner, offer: { money: num('#tr-om'), props: vals('tr-op'), cards: num('#tr-oc') }, request: { money: num('#tr-rm'), props: vals('tr-rp'), cards: num('#tr-rc') } });
    if (!r.error) { ui.modal = null; ui.lastModalKey = ''; }
  };
}

function auctionHTML() {
  const au = S.auction, sq = BOARD[au.idx];
  const mp = S.players.find((p) => p.id === me);
  const passed = au.passed.includes(me) || mp.bankrupt;
  const high = au.bidder === me;
  const incs = [1, 10, 50, 100];
  const bidder = au.bidder ? pName(au.bidder) : null;
  const btns = incs.map((n) => { const amt = au.bid + n; return `<button data-act="bid" data-amt="${amt}" ${passed || high || amt > mp.money ? 'disabled' : ''}>+${n}<br><small>${money(amt)}</small></button>`; }).join('');
  const waiting = S.players.filter((p) => !p.bankrupt && !au.passed.includes(p.id) && p.id !== au.bidder).map((p) => esc(p.name));
  return `<div class="mbox"><h2>🔨 Auction: ${esc(sq.name)}</h2>
    <div class="sub">List price ${money(sq.price)}</div>${deedHTML(au.idx)}
    <div class="bidinfo">${au.bidder ? `${money(au.bid)} <small style="font-size:16px;color:var(--ink)">by ${bidder}</small>` : 'No bids yet'}</div>
    <div class="bidgrid">${btns}</div>
    <div class="btns"><button data-act="pass" ${passed || high ? 'disabled' : ''}>${passed ? 'You passed' : high ? "You're winning" : 'Pass'}</button></div>
    <p class="sub" style="margin-top:10px">${waiting.length ? 'Still deciding: ' + waiting.join(', ') : ''}</p></div>`;
}

function tradeModalHTML() {
  const t = S.trade;
  if (t.to === me) {
    return `<div class="mbox"><h2>🤝 Trade offer</h2><div class="tl"><b>${pName(t.from)}</b> offers you: ${sideHTML(t.offer)}</div><div class="tl">They want from you: ${sideHTML(t.request)}</div>
      <div class="btns"><button data-act="tradeDecline">Decline</button><button class="good" data-act="tradeAccept">Accept</button></div></div>`;
  }
  return `<div class="mbox"><h2>🤝 Waiting for ${pName(t.to)}…</h2><div class="tl">You give: ${sideHTML(t.offer)}</div><div class="tl">You get: ${sideHTML(t.request)}</div>
    <div class="btns"><button data-act="tradeCancel">Cancel offer</button></div></div>`;
}

function renderModal() {
  const m = $('#modal');
  let key = '', html = '';
  if (S.phase === 'auction' && S.auction) { key = 'auction' + S.auction.bid + S.auction.passed.join(',') + S.auction.bidder + (S.auction.passed.length); html = auctionHTML(); }
  else if (S.trade && (S.trade.to === me || S.trade.from === me)) { key = 'trade' + S.trade.id; html = tradeModalHTML(); }
  else if (ui.modal) {
    if (ui.modal.type === 'detail') { key = 'detail' + ui.modal.idx + (S.props[ui.modal.idx] ? S.props[ui.modal.idx].owner : ''); html = `<div class="mbox">${deedHTML(ui.modal.idx)}<div class="btns"><button data-ui="close">Close</button></div></div>`; }
    else if (ui.modal.type === 'composer') { key = 'composer' + ui.modal.partner; html = composerHTML(); }
  }
  if (!key) { m.hidden = true; ui.lastModalKey = ''; return; }
  if (key !== ui.lastModalKey) {
    m.innerHTML = html; ui.lastModalKey = key;
    if (ui.modal && ui.modal.type === 'composer' && key.startsWith('composer')) wireComposer();
  }
  m.hidden = false;
}

// ---------- global events ----------
document.addEventListener('click', (e) => {
  const b = e.target.closest('[data-act]');
  if (b && !b.disabled) {
    if (b.dataset.confirm && !confirm(b.dataset.confirm)) return;
    const extra = {};
    if (b.dataset.idx !== undefined) extra.idx = +b.dataset.idx;
    if (b.dataset.amt !== undefined) extra.amount = +b.dataset.amt;
    if (b.dataset.id !== undefined) extra.id = +b.dataset.id;
    act(b.dataset.act, extra);
    return;
  }
  const u = e.target.closest('[data-ui]');
  if (u && !u.disabled) {
    if (u.dataset.ui === 'close') { ui.modal = null; ui.lastModalKey = ''; renderModal(); }
    if (u.dataset.ui === 'trade') { ui.modal = { type: 'composer', partner: null }; ui.lastModalKey = ''; renderModal(); }
    return;
  }
  const sq = e.target.closest('[data-sq]');
  if (sq && S && S.phase !== 'lobby' && !(S.phase === 'auction')) {
    ui.modal = { type: 'detail', idx: +sq.dataset.sq }; ui.lastModalKey = ''; renderModal();
    return;
  }
  if (e.target.id === 'modal' && ui.modal) { ui.modal = null; ui.lastModalKey = ''; renderModal(); }
});

function render() {
  if (!S) return;
  if (S.phase === 'lobby') { show('lobby'); renderLobby(); return; }
  if (!$('#lobby').hidden || !$('#home').hidden) show('game');
  animateDice();
  renderBoard(); renderPlayers(); renderMine(); renderLog(); renderModal();
}

// ---------- boot ----------
(async function boot() {
  try { BOARD = await (await fetch('/api/board')).json(); } catch (e) { toast('Cannot load board'); }
  try {
    const s = JSON.parse(localStorage.getItem('ee-session') || 'null');
    if (s && s.code && s.pid && s.secret) { code = s.code; me = s.pid; secret = s.secret; connect(); }
  } catch (e) {}
})();
